

        $('.funding-contributors1').slick({
            dots: false,
            infinite: false,
            speed: 300,
            slidesToShow: 4,
            slidesToScroll: 4,
            responsive: [
                {
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        infinite: true,
                        dots: false
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
            ]
        });

        $('.funding-contributors1').on('afterChange', function () {
            console.log($('.funding-contributors1').slick('slickCurrentSlide'));
            var currentSlide = $('.funding-contributors1').slick('slickCurrentSlide');
            if (currentSlide == 0) {
                $('.funding-contributors1 .slick-prev').hide();
                $('.funding-contributors1 .slick-next').show();
            }
            else if (currentSlide == 8) {
                $('.funding-contributors1 .slick-next').hide();
                $('.funding-contributors1 .slick-prev').show();
            }

            if (currentSlide > 0 && currentSlide < 8) {
                $('.funding-contributors1 .slick-prev').show();
                $('.funding-contributors1 .slick-next').show();
            }

        });

        $(document).ready(function () {
            var currentSlide = $('.funding-contributors1').slick('slickCurrentSlide');
            if (currentSlide == 0) {
                $('.funding-contributors1 .slick-prev').hide();
            }
            else if (currentSlide == 8) {
                $('.funding-contributors1 .slick-next').hide();
            }

        });



        $('.our-partner-slide').slick({
            dots: false,
            infinite: false,
            speed: 300,
            slidesToShow: 4,
            slidesToScroll: 4,
            responsive: [
                {
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        infinite: true,
                        dots: false
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
            ]
        });

        $('.our-partner-slide').on('afterChange', function () {
            console.log($('.our-partner-slide').slick('slickCurrentSlide'));
            var currentSlide = $('.our-partner-slide').slick('slickCurrentSlide');
            if (currentSlide == 0) {
                $('.our-partner-slide .slick-prev').hide();
                $('.our-partner-slide .slick-next').show();
            }
            else if (currentSlide == 8) {
                $('.our-partner-slide .slick-next').hide();
                $('.our-partner-slide .slick-prev').show();
            }

            if (currentSlide > 0 && currentSlide < 8) {
                $('.our-partner-slide .slick-prev').show();
                $('.our-partner-slide .slick-next').show();
            }

        });

        $(document).ready(function () {
            var currentSlide = $('.our-partner-slide').slick('slickCurrentSlide');
            if (currentSlide == 0) {
                $('.our-partner-slide .slick-prev').hide();
            }
            else if (currentSlide == 8) {
                $('.our-partner-slide .slick-next').hide();
            }

        });


        $('.advisor-slider').slick({
            dots: false,
            infinite: false,
            speed: 300,
            slidesToShow: 3,
            slidesToScroll: 3,
            responsive: [
                {
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        infinite: true,
                        dots: false
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
            ]
        });
        $('.advisor-slider1').slick({
            dots: false,
            infinite: false,
            speed: 300,
            slidesToShow: 3,
            slidesToScroll: 3,
            responsive: [
                {
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        infinite: true,
                        dots: false
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
            ]
        });

        $('.advisor-slider2').slick({
            dots: false,
            infinite: false,
            speed: 300,
            slidesToShow: 3,
            slidesToScroll: 3,
            responsive: [
                {
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        infinite: true,
                        dots: false
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
            ]
        });




        $('button[role="tab"]').on('shown.bs.tab', function (e) {
            console.log("innnnnnnnn");
  $('.advisor-slider').slick('setPosition');
  $('.advisor-slider1').slick('setPosition');
  $('.advisor-slider2').slick('setPosition');
})
        $(document).ready(function () {
            var currentSlide1 = $('.advisor-slider').slick('slickCurrentSlide');
            var currentSlide2 = $('.advisor-slider1').slick('slickCurrentSlide');
            var currentSlide3 = $('.advisor-slider2').slick('slickCurrentSlide');
         /*   
            if (currentSlide1 == 0) {
                $('.advisor-slider .slick-prev').hide();
            }
            else if (currentSlide1 == 6) {
                $('.advisor-slider .slick-next').hide();
            }

            if (currentSlide1 == 0) {
                $('.advisor-slider .slick-prev').hide();
            }
            else if (currentSlide == 6) {
                $('.advisor-slider .slick-next').hide();
            }

            if (currentSlide1 == 0) {
                $('.advisor-slider .slick-prev').hide();
            }
            else if (currentSlide == 6) {
                $('.advisor-slider .slick-next').hide();
            }
            */
        });

        // $('.advisor-slider').on('afterChange', function () {
        //     console.log($('.advisor-slider').slick('slickCurrentSlide'));
        //     var currentSlide = $('.advisor-slider').slick('slickCurrentSlide');
        //     if (currentSlide == 0) {
        //         $('.advisor-slider .slick-prev').hide();
        //         $('.advisor-slider .slick-next').show();
        //     }
        //     else if (currentSlide == 6) {
        //         $('.advisor-slider .slick-next').hide();
        //         $('.advisor-slider .slick-prev').show();
        //     }

        //     if (currentSlide > 0 && currentSlide < 6) {
        //         $('.advisor-slider .slick-prev').show();
        //         $('.advisor-slider .slick-next').show();
        //     }

        // });

        // $(document).ready(function () {
        //     var currentSlide = $('.advisor-slider').slick('slickCurrentSlide');
        //     if (currentSlide == 0) {
        //         $('.advisor-slider .slick-prev').hide();
        //     }
        //     else if (currentSlide == 6) {
        //         $('.advisor-slider .slick-next').hide();
        //     }

        // });


    